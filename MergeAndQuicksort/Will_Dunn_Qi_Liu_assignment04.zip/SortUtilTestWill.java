package assignment04;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

import static org.junit.Assert.*;

public class SortUtilTestWill {
    private static Random rand = new Random();
    private ArrayList<String> testStringArray = new ArrayList<String>();
    private ArrayList<Integer> testIntegerArray = new ArrayList<Integer>();
    public int size = 10;


    @Before
    public void setUp() throws Exception {
        //setup the integer ArrayList
        testIntegerArray.add(3);
        testIntegerArray.add(4);
        testIntegerArray.add(5);
        testIntegerArray.add(2);
        testIntegerArray.add(7);
        testIntegerArray.add(8);
        testIntegerArray.add(6);
        testIntegerArray.add(1);

        //setup the string ArrayList
        testStringArray.add("a");
        testStringArray.add("g");
        testStringArray.add("b");
        testStringArray.add("e");
        testStringArray.add("h");
        testStringArray.add("b");
        testStringArray.add("w");
        testStringArray.add("q");
        testStringArray.add("a");
    }

    @Test
    public void testMergesortInt() {
        SortUtil<Integer> test = new SortUtil<>();
        test.mergesortAlgorithm(testIntegerArray, (lhs, rhs) -> lhs.compareTo(rhs));

        for (int mergeIter = 0; mergeIter < testIntegerArray.size() - 1; mergeIter++) {
            if (testIntegerArray.get(mergeIter) > testIntegerArray.get(mergeIter + 1)) {
                fail("Your element is greater than the next element.");
            }
        }
        assertTrue(true); // Made it through the test
    }

    @Test
    public void testQuicksortRandomPivot() {
        ArrayList<Integer> testPivot = SortUtil.generateAverageCase(1000);
        SortUtil.quicksort(testPivot, (lhs, rhs) -> lhs.compareTo(rhs));
        for(Integer inty : testPivot){
            System.out.println(inty);
        }
    }




    @Test
    public void testQuicksortInt() {
        SortUtil.quicksort(testIntegerArray, (lhs, rhs) -> lhs.compareTo(rhs));

        for (int quickIter = 0; quickIter < testIntegerArray.size() - 1; quickIter++) {
            //System.out.println(testIntegerArray.get(quickIter));
            if (testIntegerArray.get(quickIter).intValue() > testIntegerArray.get(quickIter + 1).intValue()) {
                fail("Your element is greater than the next element.");
            }
        }
        assertTrue(true); // Made it through the test
    }

    @Test
    public void testMergesortString() {
        SortUtil.mergesort(testStringArray, (lhs, rhs) -> lhs.compareTo(rhs));

        for (int mergeIter = 0; mergeIter < testIntegerArray.size() - 1; mergeIter++) {
            if (testStringArray.get(mergeIter).compareTo(testStringArray.get(mergeIter + 1)) > 0) {
                fail("Your element is greater than the next element.");
            }
        }
        assertTrue(true); // Made it through the test
    }

    @Test
    public void testQuicksortString() {
        SortUtil.quicksort(testStringArray, (lhs, rhs) -> lhs.compareTo(rhs));

        for (int quickIter = 0; quickIter < testIntegerArray.size() - 1; quickIter++) {
            //System.out.println(testIntegerArray.get(quickIter));
            if (testStringArray.get(quickIter).compareTo(testStringArray.get(quickIter + 1)) > 0) {
                fail("Your element is greater than the next element.");
            }
        }
        assertTrue(true); // Made it through the test
    }

    @Test
    public void testGenerateAscending() {
        ArrayList<Integer> ascendingList = SortUtil.generateBestCase(size);

        for (int ascendingIter = 0; ascendingIter < ascendingList.size() - 1; ascendingIter++) {
            if (ascendingList.get(ascendingIter) > ascendingList.get(ascendingIter + 1)) {
                fail("Your element is greater than the next element.");
            }
            assertTrue(true); // Made it through the test
        }
    }


    @Test
    public void testGenerateShuffled() {

        ArrayList<Integer> shuffledList = SortUtil.generateAverageCase(size);

        if (shuffledList.get(2) - shuffledList.get(1) - shuffledList.get(0) == 0)
            fail("Your element is less than the next element.");

        assertTrue(true);
    }

    @Test
    public void testGenerateDescending() {

        ArrayList<Integer> descendingList = SortUtil.generateWorstCase(size);

        for (int descendingIter = 0; descendingIter < descendingList.size() - 1; descendingIter++) {
            if (descendingList.get(descendingIter) < descendingList.get(descendingIter + 1)) {
                fail("Your element is less than the next element.");
            }
            assertTrue(true); // Made it through the test
        }
    }

    @Test
    public void testQuicksort1() {
        ArrayList<Integer> test = SortUtil.generateAverageCase(1000);
        SortUtil.quicksort(test, (lhs, rhs) -> lhs.compareTo(rhs));
        for (Integer element : test) {
            System.out.println(element);
        }
        assertTrue(true);
    }

//	@Test
//	public void testQuicksort2() {
//		SortUtil.quicksort(testStringArray, (lhs, rhs) -> lhs.compareTo(rhs));
//		for (String element : testStringArray) {
//			System.out.println(element);
//		}
//		assertTrue(true);
//	}

    @Test
    public void testMergesortToConsole1() {
        SortUtil.mergesortAlgorithm(testIntegerArray, (lhs, rhs) -> lhs.compareTo(rhs));
//		for (Integer element : testIntegerArray) {
//			System.out.println(element);
//		}
        for (int i = 0; i < testIntegerArray.size() - 1; i++) {
            if (testIntegerArray.get(i) > testIntegerArray.get(i + 1)) assertTrue(false);
        }
        assertTrue(true);
    }

    @Test
    public void exhaustiveMergesort() {
        ArrayList<Integer> eAL = SortUtil.generateAverageCase(1_000);
        SortUtil.mergesort(eAL, (lhs, rhs) -> lhs.compareTo(rhs));
        for (Integer inty : eAL) {
            //System.out.println(inty);
        }
        for (int i = 0; i < eAL.size() - 1; i++) {
            if (eAL.get(i) > eAL.get(i + 1)) fail("exhaustiveMergesort failed at: " + i);
        }
    }

    @Test
    public void testMergesortToConsole2() {
        SortUtil.mergesortAlgorithm(testStringArray, (lhs, rhs) -> lhs.compareTo(rhs));
//		for (String element : testStringArray) {
//			System.out.println(element);
//		}
        assertTrue(true);
    }

public static class ComparatorForTests implements Comparator<Integer> {
    /**
     * @param lhs
     * @param rhs
     * @return int based on the difference in integers.
     */
    @Override
    public int compare(Integer lhs, Integer rhs) {
        return lhs - rhs;
    }
}

public static class ComparatorForTestsString implements Comparator<String> {
    /**
     * @param lhs
     * @param rhs
     * @return int based on the difference in integers.
     */
    @Override
    public int compare(String lhs, String rhs) {
        return lhs.compareTo(rhs);
    }
}
}