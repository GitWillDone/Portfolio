package assignment04;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import org.junit.Test;

/*
 * JUnit test for methods in SortUtil, such as Mergesort, Quicksort,
 *  generateAscending, generateDescending and generateShuffled
 * 
 *  @author Qi Liu, Will Dunn
 */

public class SortUtilTestQi {
	// Test Mergesort method when the input arraylist and comparator is null;
	@Test(expected = NullPointerException.class)
	public void testMergeSort() {
		ArrayList<String> input = null;
		Comparator<String> comp = null;
		SortUtil.mergesort(input, comp);
	}

	// Test Quicksort method when the input arraylist and comparator is null;
	@Test(expected = NullPointerException.class)
	public void testQuickSort() {
		ArrayList<String> input = null;
		Comparator<String> comp = null;
		SortUtil.quicksort(input, comp);
	}

	// Test Mergesort method when there is only one element which type is Integer in
	// the input arraylist.
	@Test
	public void testMergeSortIntegerJustOne() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(1);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there is only one element which type is Integer in
	// the input arraylist.
	@Test
	public void testQuickSortIntegerJustOne() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(1);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are few elements which type is Integer in
	// the input arraylist.
	@Test
	public void testMergeSortIntegerSmall() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(2);
		input.add(1);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are few elements which type is Integer in
	// the input arraylist.
	@Test
	public void testQuickSortIntegerSmall() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(2);
		input.add(1);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are even elements which type is Integer in
	// the input arraylist.
	@Test
	public void testMergeSortIntegerEven() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(1);
		input.add(5);
		input.add(4);
		input.add(2);
		input.add(3);
		input.add(8);
		input.add(6);
		input.add(7);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are odd elements which type is Integer in
	// the input arraylist.
	@Test
	public void testMergeSortIntegerOdd() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(1);
		input.add(5);
		input.add(4);
		input.add(2);
		input.add(3);
		input.add(6);
		input.add(7);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are even elements which type is Integer in
	// the input arraylist.
	@Test
	public void testQuickSortIntegerEven() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(1);
		input.add(5);
		input.add(4);
		input.add(2);
		input.add(3);
		input.add(8);
		input.add(6);
		input.add(7);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are odd elements which type is Integer in
	// the input arraylist.
	@Test
	public void testQuickSortIntegerOdd() {
		ArrayList<Integer> input = new ArrayList<>();
		input.add(1);
		input.add(5);
		input.add(4);
		input.add(2);
		input.add(3);
		input.add(6);
		input.add(7);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= input.size(); i++) {
			result.add(i);
		}

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there is only one element which type is Character
	// in the input arraylist.
	@Test
	public void testMergeSortCharacterJustOne() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('a');
		ArrayList<Character> result = new ArrayList<>();
		result.add('a');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there is only one element which type is Character
	// in the input arraylist.
	@Test
	public void testQuickSortCharacterJustOne() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('a');
		ArrayList<Character> result = new ArrayList<>();
		result.add('a');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are few elements which type is Character in
	// the input arraylist.
	@Test
	public void testMergeSortCharacterSmall() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('b');
		input.add('a');
		ArrayList<Character> result = new ArrayList<>();
		result.add('a');
		result.add('b');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are few elements which type is Character in
	// the input arraylist.
	@Test
	public void testQuickSortCharacterSmall() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('b');
		input.add('a');

		ArrayList<Character> result = new ArrayList<>();
		result.add('a');
		result.add('b');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are even elements which type is Character in
	// the input arraylist.
	@Test
	public void testMergeSortCharacterEven() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('b');
		input.add('e');
		input.add('f');
		input.add('c');
		input.add('g');
		input.add('a');
		input.add('h');
		input.add('d');

		ArrayList<Character> result = new ArrayList<>();
		result.add('a');
		result.add('b');
		result.add('c');
		result.add('d');
		result.add('e');
		result.add('f');
		result.add('g');
		result.add('h');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are odd elements which type is Character in
	// the input arraylist.
	@Test
	public void testMergeSortCharacterOdd() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('b');
		input.add('e');
		input.add('f');
		input.add('c');
		input.add('g');
		input.add('a');
		input.add('d');

		ArrayList<Character> result = new ArrayList<>();
		result.add('a');
		result.add('b');
		result.add('c');
		result.add('d');
		result.add('e');
		result.add('f');
		result.add('g');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are even elements which type is Character in
	// the input arraylist.
	@Test
	public void testQuickSortCharacterEven() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('b');
		input.add('e');
		input.add('f');
		input.add('c');
		input.add('g');
		input.add('a');
		input.add('h');
		input.add('d');

		ArrayList<Character> result = new ArrayList<>();
		result.add('a');
		result.add('b');
		result.add('c');
		result.add('d');
		result.add('e');
		result.add('f');
		result.add('g');
		result.add('h');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are odd elements which type is Character in
	// the input arraylist.
	@Test
	public void testQuickSortCharacterOdd() {
		ArrayList<Character> input = new ArrayList<>();
		input.add('b');
		input.add('e');
		input.add('f');
		input.add('c');
		input.add('g');
		input.add('a');
		input.add('d');

		ArrayList<Character> result = new ArrayList<>();
		result.add('a');
		result.add('b');
		result.add('c');
		result.add('d');
		result.add('e');
		result.add('f');
		result.add('g');

		Comparator<Character> comp = (lhs, rhd) -> {
			Character left = lhs.charValue();
			Character right = rhd.charValue();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there is only one element which type is String in
	// the input arraylist.
	@Test
	public void testMergeSortStringJustOne() {
		ArrayList<String> input = new ArrayList<>();
		input.add("Colin");

		ArrayList<String> result = new ArrayList<>();
		result.add("Colin");

		Comparator<String> comp = (lhs, rhd) -> {
			String left = lhs.toString();
			String right = rhd.toString();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there is only one element which type is String in
	// the input arraylist.
	@Test
	public void testQuickSortStringJustOne() {
		ArrayList<String> input = new ArrayList<>();
		input.add("Colin");

		ArrayList<String> result = new ArrayList<>();
		result.add("Colin");

		Comparator<String> comp = (lhs, rhd) -> {
			String left = lhs.toString();
			String right = rhd.toString();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are few elements which type is String in the
	// input arraylist.
	@Test
	public void testMergeSortStringSmall() {
		ArrayList<String> input = new ArrayList<>();
		input.add("Colin");
		input.add("Coli");

		ArrayList<String> result = new ArrayList<>();
		result.add("Coli");
		result.add("Colin");

		Comparator<String> comp = (lhs, rhd) -> {
			String left = lhs.toString();
			String right = rhd.toString();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are few elements which type is String in the
	// input arraylist.
	@Test
	public void testQuickSortStringSmall() {
		ArrayList<String> input = new ArrayList<>();
		input.add("Colin");
		input.add("Coli");

		ArrayList<String> result = new ArrayList<>();
		result.add("Coli");
		result.add("Colin");

		Comparator<String> comp = (lhs, rhd) -> {
			String left = lhs.toString();
			String right = rhd.toString();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Mergesort method when there are few elements which type is String, with
	// uppercase and different length in the input arraylist.
	@Test
	public void testMergeSortString2() {
		ArrayList<String> input = new ArrayList<>();
		input.add("Nick");
		input.add("Mike");
		input.add("Colin");
		input.add("Anny");
		input.add("Sam");
		input.add("Coli");

		ArrayList<String> result = new ArrayList<>();
		result.add("Anny");
		result.add("Coli");
		result.add("Colin");
		result.add("Mike");
		result.add("Nick");
		result.add("Sam");

		Comparator<String> comp = (lhs, rhd) -> {
			String left = lhs.toString();
			String right = rhd.toString();
			return left.compareTo(right);
		};

		SortUtil.mergesort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test Quicksort method when there are few elements which type is String, with
	// uppercase and different length in the input arraylist.
	@Test
	public void testQuickSortString2() {
		ArrayList<String> input = new ArrayList<>();
		input.add("Nick");
		input.add("Mike");
		input.add("Colin");
		input.add("Anny");
		input.add("Sam");
		input.add("Coli");

		ArrayList<String> result = new ArrayList<>();
		result.add("Anny");
		result.add("Coli");
		result.add("Colin");
		result.add("Mike");
		result.add("Nick");
		result.add("Sam");

		Comparator<String> comp = (lhs, rhd) -> {
			String left = lhs.toString();
			String right = rhd.toString();
			return left.compareTo(right);
		};

		SortUtil.quicksort(input, comp);

		assertTrue(result.equals(input));
	}

	// Test generateAscending method in size of eight.
	@Test
	public void testgenerateAscending() {
		ArrayList<Integer> input = SortUtil.generateBestCase(8);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 1; i <= 8; i++) {
			result.add(i);
		}

		assertTrue(result.equals(input));
	}

	// Test generateDescending method in size of eight.
	@Test
	public void testgenerateDescending() {
		ArrayList<Integer> input = SortUtil.generateWorstCase(8);

		ArrayList<Integer> result = new ArrayList<>();
		for (int i = 8; i >= 1; i--) {
			result.add(i);
		}

		assertTrue(result.equals(input));
	}

	// Test generateShuffled method in size of eight.
	@Test
	public void testgenerateShuffled() {
		ArrayList<Integer> input = SortUtil.generateAverageCase(8);
		boolean greater = false;
		boolean smaller = false;

		Comparator<Integer> comp = (lhs, rhd) -> {
			Integer left = lhs.intValue();
			Integer right = rhd.intValue();
			return left.compareTo(right);
		};

		for (int i = 1; i < 8; i++) {
			if (comp.compare(input.get(i), input.get(i - 1)) > 0) {
				greater = true;
			}

			if (comp.compare(input.get(i), input.get(i - 1)) < 0) {
				smaller = true;
			}
		}

		boolean result = greater && smaller;

		assertEquals(true, result);

	}

}
